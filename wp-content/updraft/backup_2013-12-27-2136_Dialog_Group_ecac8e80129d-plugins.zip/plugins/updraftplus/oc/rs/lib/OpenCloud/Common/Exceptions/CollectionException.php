<?php

namespace OpenCloud\Common\Exceptions;

class CollectionException extends \Exception {}