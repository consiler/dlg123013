<?php
foreach($block['slides'] as $s) {
  $slide = $s['slide'][0];
  echo '<div id="'.$anchor_id.'-wrap">';
  $grl = $slide['acf_fc_layout'];
  $allowed_layouts = array("copy_left_subslider_right", "single_copy_slide");
  if(in_array($grl, $allowed_layouts))
    include('indexed_slider/'.$grl.".php");
  else
    t_err("Layout ".$grl." not in allowed layouts.");
  echo '</div>';
}
?>