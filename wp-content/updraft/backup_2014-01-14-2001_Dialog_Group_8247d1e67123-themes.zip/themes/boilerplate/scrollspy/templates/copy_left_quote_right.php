<?php
/* Layout Variables
 * copy
 * quote
 * quoted_person_name
 * quoted_person_title
 */
$copy = get_sub_field("copy");
$quote = get_sub_field("quote");
$quoted_person_name = get_sub_field("quoted_person_name");
$quoted_person_title = get_sub_field("quoted_person_title");
?>