/*
	Any site-specific scripts you might have.
	Note that <html> innately gets a class of "no-js".
	This is to allow you to react to non-JS users.
	Recommend removing that and adding "js" as one of the first things your script does.
	This will do it:
	document.documentElement.className = document.documentElement.className.replace('no-js', 'js');
	* Note that if you are using Modernizr, it already does this for you. :-)
*/