<?php

namespace OpenCloud\Common\Exceptions;

class UpdateError extends \Exception {}
