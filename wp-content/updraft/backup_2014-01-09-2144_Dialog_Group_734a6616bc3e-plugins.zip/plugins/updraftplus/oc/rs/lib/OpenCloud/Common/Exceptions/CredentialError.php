<?php

namespace OpenCloud\Common\Exceptions;

class CredentialError extends \Exception {}
