<?php

namespace OpenCloud\Common\Exceptions;

class DomainError extends \Exception {}
