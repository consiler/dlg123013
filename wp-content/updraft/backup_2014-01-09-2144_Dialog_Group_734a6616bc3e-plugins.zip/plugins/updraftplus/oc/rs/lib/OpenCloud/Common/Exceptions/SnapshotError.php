<?php

namespace OpenCloud\Common\Exceptions;

class SnapshotError extends \Exception {}
