<?php

namespace OpenCloud\Common\Exceptions;

class ContainerNotFoundError extends \Exception {}
