<?php

namespace OpenCloud\Common\Exceptions;

class NetworkError extends \Exception {}
