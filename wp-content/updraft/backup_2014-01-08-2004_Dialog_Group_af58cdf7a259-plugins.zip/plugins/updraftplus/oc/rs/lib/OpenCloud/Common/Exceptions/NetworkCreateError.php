<?php

namespace OpenCloud\Common\Exceptions;

class NetworkCreateError extends \Exception {}
