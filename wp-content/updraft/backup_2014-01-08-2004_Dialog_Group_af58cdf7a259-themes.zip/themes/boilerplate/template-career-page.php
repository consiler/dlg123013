<?php
/*
 * Template Name: Careers Page
 */
get_header(); ?>
<div id="internal-wrap">
  <?php get_template_part('template', 'internal-header'); ?>
  <div id="internal-lower-wrap">
    <div id="internal-lower" class="centered">
      <div id="internal-main" class="internal-main-fullwidth">
        <div id="career-page">
          <h2><?php the_field('top_text'); ?></h2>
          <img src="<?php the_field('values_image');?>"/>
          <div id="career-learn-more-wrap">
            <div id="career-learn-more">
              <a href="\our-team"><span class="career-learn-more-button">Learn more about our team</span></a>
            </div>
          </div>
          <div class="value">
            <h2><?php the_field('center_text');?></h2>
            <h3><?php the_field('sub_center_text');?></h3>
          </div>
          <?php get_template_part('template', '3-columns'); ?>

          <div id="job-listings-wrap">
          <img id="open-jobs"src="<?php the_field('open_jobs_image')?>">
            <div id="job-listings">
              <table id="jobs">            
                  <thead>
                    <tr>
                      <th><h2>Position<h2></th>
                      <th><h2>Location</h2></th>
                    </tr>
                  </thead>
                  <tbody>

                <? $args = array( 'post_type' => 'job_listings' );
              $loop = new WP_Query( $args );
              while ( $loop->have_posts() ) : $loop->the_post();
                ?>
                    <tr>
                      <td><?php the_field('position');?></td>
                      <td><?php the_field('location');?></td>
                      <td><a href="#"><img src="http://dialog.local/wp-content/uploads/2013/12/job-detail-button_16.png"/></a></td>
                      
                    </tr>
                   <?php endwhile; ?>
                  </tbody>

              </table>
            </div>
          </div>


        </div>
      </div>
    </div>
  </div>
</div>
<?php get_footer(); ?>